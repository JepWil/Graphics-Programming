// main.cc

#include <halcyon_file_formats.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>

#define BIT(sh) (1 << sh)

enum compiler_format_type_id
{
   COMPILER_FORMAT_MODEL,
   COMPILER_FORMAT_COUNT,
   COMPILER_FORMAT_INVALID,
};

struct compiler_settings
{
   compiler_format_type_id type_;
   const char *path_;
   bool dump_;
   union
   {
      struct
      {
         const char *mesh_name_;
      } model_;
   };
};

static int 
usage(const char *arg0)
{
   printf("usage: %s [options]\n\n", arg0);
   puts  ("          --model     file-path");
   puts  ("          --mesh      mesh-name");
   puts  ("          --dump");
   return 0;
}

static int 
error(const char *format, ...)
{
   va_list args;
   va_start(args, format);
   vprintf(format, args);
   va_end(args);
   return 0;
}

static void
indent(int depth)
{
   char buf[128] = {};
   if (depth > sizeof(buf) - 2)
      depth = sizeof(buf) - 2;

   while (depth--) { buf[depth] = ' '; }
   printf("%s", buf);
}

static void
node_information(const aiNode *node, int depth)
{
   indent(depth * 2);
   printf("name: %s\n", node->mName.C_Str());

   if (node->mMetaData)
   {
      const unsigned count = node->mMetaData->mNumProperties;
      for (unsigned index = 0; index < count; index++)
      {
         const aiString *key = nullptr;
         const aiMetadataEntry *meta = nullptr;
         node->mMetaData->Get(index, key, meta);

         indent(depth * 2);
         printf("- meta: %s\n", key->C_Str());
      }
   }

   indent(depth * 2);
   printf("- meshes: %d\n", node->mNumMeshes);

   indent(depth * 2);
   printf("- children: %d\n", node->mNumChildren);

   if (node->mNumChildren > 0)
   {
      const unsigned count = node->mNumChildren;
      for (unsigned index = 0; index < count; index++)
      {
         const aiNode *child = node->mChildren[index];
         node_information(child, depth + 1);
      }
   }
}

static void
scene_information(const aiScene *scene)
{
   puts("file information:");
   node_information(scene->mRootNode, 0);
}

static void
push_attribute(halcyon_model_vertex_format &format, int type, int count)
{
   int index = format.attribute_count_++;
   format.attributes_[index * 2 + 0] = (uint8_t)type;
   format.attributes_[index * 2 + 1] = (uint8_t)count;

   switch (count)
   {
      case 1: 
      case 2: 
      case 3: 
      case 4: 
         format.stride_ += sizeof(float) * count; 
         break;
      default:
         *(volatile int *)0 = 0; 
         break;
   }
}

static void
determine_vertex_format(const aiMesh *mesh, halcyon_model_vertex_format &format)
{
   push_attribute(format, BIT(vertex_format::ATTRIBUTE_SEMANTIC_POSITION), 3);
   if (mesh->HasTextureCoords(0))
      push_attribute(format, BIT(vertex_format::ATTRIBUTE_SEMANTIC_TEXCOORD), 2);
   /*if (mesh->HasNormals())
      push_attribute(format, BIT(vertex_format::ATTRIBUTE_SEMANTIC_NORMAL), 3);
   if (mesh->HasVertexColors(0))
      push_attribute(format, BIT(vertex_format::ATTRIBUTE_SEMANTIC_COLOR), 4);*/
}

static bool
compile_and_save_mesh(const aiMesh *mesh, const char *path)
{
   char filepath[1024] = {};
   strcpy_s(filepath, sizeof(filepath), path);
   strcat_s(filepath, sizeof(filepath), ".");
   strcat_s(filepath, sizeof(filepath), mesh->mName.C_Str());
   strcat_s(filepath, sizeof(filepath), ".model");

   printf("compiling mesh: %s\n", filepath);

   FILE *fout = nullptr;
   fopen_s(&fout, filepath, "wb");
   if (!fout)
      return false;

   halcyon_model_vertex_format format = {};
   determine_vertex_format(mesh, format);

   // note: write the vertex data to the memory buffer
   uint32_t face_count = mesh->mNumFaces;
   uint32_t vertex_count = face_count * 3;
   uint32_t vertex_buffer_size = vertex_count * format.stride_;
   const uint8_t *vertex_buffer_base = new uint8_t[vertex_buffer_size];
   uint8_t *dst = (uint8_t *)vertex_buffer_base;
   for (uint32_t face_index = 0; face_index < face_count; face_index++)
   {
      for (int vertex_index = 0; vertex_index < 3; vertex_index++)
      {
         unsigned index = mesh->mFaces[face_index].mIndices[vertex_index];
         
         // note: write position
         *(aiVector3D *)dst = mesh->mVertices[index];
         dst += sizeof(aiVector3D);

         if (mesh->HasTextureCoords(0))
         {
            aiVector3D vec = mesh->mTextureCoords[0][index];
            *(aiVector2D *)dst = aiVector2D(vec.x, vec.y);
            dst += sizeof(aiVector2D);
         }
         /*if (mesh->HasNormals())
         {
            *(aiVector3D *)dst = mesh->mNormals[index];
            dst += sizeof(aiVector3D);
         }
         if (mesh->HasVertexColors(0))
         {
            *(aiColor4D *)dst = mesh->mColors[0][index];
            dst += sizeof(aiColor4D);
         }*/

         if (dst >= (vertex_buffer_base + vertex_buffer_size))
         {
            int asd = 0;
         }
      }
   }

   // note: contruct file header
   halcyon_model_file_header header = {};
   header.magic_ = HALCYON_MODEL_MAGIC;
   header.version_ = HALCYON_MODEL_VERSION;
   header.primitive_count_ = vertex_count;
   header.format_ = format;

   // note: write header
   fwrite(&header, sizeof(halcyon_model_file_header), 1, fout);

   // note: write vertex data
   fwrite(vertex_buffer_base, 1, vertex_buffer_size, fout);

   // note: flush and close file handle
   fflush(fout);
   fclose(fout);

   delete[] vertex_buffer_base;

   return true;
}

static bool
compile_model(compiler_settings settings)
{
   Assimp::Importer importer;
   const aiScene *scene = importer.ReadFile(settings.path_, aiProcessPreset_TargetRealtime_MaxQuality);

   if (!scene || !scene->mRootNode || (scene->mFlags & AI_SCENE_FLAGS_INCOMPLETE))
   {
      printf("error: %s\n", importer.GetErrorString());
      return false;
   }

   if (settings.dump_)
   {
      scene_information(scene);
   }
   else
   {
      bool single_mesh_selected = false;
      if (settings.model_.mesh_name_)
      {
         single_mesh_selected = settings.model_.mesh_name_ ? true : false;
         printf("processing: %s (%s)\n", settings.path_, settings.model_.mesh_name_);
      }
      else
      {
         printf("processing: %s\n", settings.path_);
      }

      const aiNode *root = scene->mRootNode;
      const unsigned count = root->mNumChildren;
      for (unsigned index = 0; index < count; index++)
      {
         const aiNode *node = root->mChildren[index];
         if (!single_mesh_selected)
         {
            if (node->mNumMeshes == 0)
               continue;

            const aiMesh *mesh = scene->mMeshes[node->mMeshes[0]];
            if (!compile_and_save_mesh(mesh, settings.path_))
            {
               error("error: failed to compile and save mesh '%s'\n", mesh->mName.C_Str());
               return false;
            }
         }
         else
         {
            if (strcmp(node->mName.C_Str(), settings.model_.mesh_name_) == 0)
            {
               const aiMesh *mesh = scene->mMeshes[node->mMeshes[0]];
               if (!compile_and_save_mesh(mesh, settings.path_))
               {
                  error("error: failed to compile and save mesh '%s'\n", mesh->mName.C_Str());
                  return false;
               }
               break;
            }
         }
      }
   }

   printf("done.\n");

   return true;
}

static bool 
parse_args(int argc, char **argv, compiler_settings &settings)
{
   if (argc == 1)
      return false;

   bool result = false;

   for (int index = 1; index < argc; index++)
   {
      const char *arg = argv[index];
      if (arg[0] == '-' && arg[1] == '-')
      {
         // flag
         if (strcmp(arg, "--model") == 0)
         {
            if (argc <= index + 1)
            {
               error("error: missing argument for '--model'\n\n");
               return false;
            }

            index++;

            const char *path = argv[index];
            if (path[0] == '-' && path[1] == '-')
            {
               error("error: '%s' invalid parameter\n", path);
               return false;
            }

            settings.type_ = COMPILER_FORMAT_MODEL;
            settings.path_ = path;
            result = true;
         }
         else if (strcmp(arg, "--mesh") == 0)
         {
            if (settings.type_ != COMPILER_FORMAT_MODEL)
            {
               error("error: invalid asset format setting (forgot --model option?)\n\n");
               return false;
            }
            else if (argc <= index + 1)
            {
               error("error: missing argument for '--mesh'\n\n");
               return false;
            }

            index++;
            const char *name = argv[index];
            if (name[0] == '-' && name[1] == '-')
            {
               error("error: '%s' invalid parameter\n\n", name);
               return false;
            }

            settings.model_.mesh_name_ = name;
            result = true;
         }
         else if (strcmp(arg, "--dump") == 0)
         {
            settings.dump_ = true;
            result = true;
         }

      }
   }

   return result;
}

int main(int argc, char **argv)
{
   compiler_settings settings = { COMPILER_FORMAT_INVALID };
   if (!parse_args(argc, argv, settings))
      return usage(argv[0]);

   switch (settings.type_)
   {
      case COMPILER_FORMAT_MODEL:
      {
         compile_model(settings);
      } break;
      default:
      {
         return usage(argv[0]);
      } break;
   }

   return 0;
}
