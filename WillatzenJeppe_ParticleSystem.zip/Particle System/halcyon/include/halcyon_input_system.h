// halcyon_input_system.h

#ifndef HALCYON_INPUT_SYSTEM_H_INCLUDED
#define HALCYON_INPUT_SYSTEM_H_INCLUDED

// note: keyboard, mouse

#endif // HALCYON_INPUT_SYSTEM_H_INCLUDED
