#pragma once
//ORIGINALLY BY user bbali @ 
//https://codereview.stackexchange.com/questions/103901/implement-java-hasnext-and-next-in-c

#include <iostream>
#include <vector>
#include <string>

template <class T>
class iterator {
public:
	iterator() {}
	iterator(std::vector<T> vec) {
		container = vec;
	}
	bool hasNext() {
		if (curr_pos == container.size()) {
			return false;
		}
		else {
			if (curr_pos < container.size()) {
				return true;
			}
		}
		return false;
	}
	T& next() {
		if (hasNext()) {
			curr_pos += 1;
			return container.at(curr_pos - 1);
		}
	}

	void remove()
	{
		
	}

	// note: setter for container
	void setContainer(std::vector<T> vec) {
		 container = vec;
	}

private:	
	std::vector<T> container;
	int curr_pos = 0;
};

