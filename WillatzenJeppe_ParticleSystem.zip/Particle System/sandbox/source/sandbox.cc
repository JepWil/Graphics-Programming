// sandbox.cc

// Particle Effect/System exam hand-in by Jeppe Willatzen 220993-4716 for: Spelprogrammering av realtidsgrafik 1, 7.5 hp, Supervisor: Tommi Lipponen

// ** Checklist **
// Billboarding is done separately for the emitters in render() in sandbox.cc
// Sorting back-to-front is done using a struct in sandbox.h. Insertion-sort is currently active ** bubble-sort is inactive. 
// Emitters are generated at the bottom of init() in sandbox.cc and implemented as a struct in sandbox.h
// Size difference is determined by individually for emitters in the "CONTROL BOX" below. _scale sets the initial scale, sfactor is the factor by which the _scale changes.

#include "sandbox.h"
#include "render_system_utility.h"
#include "image.h"
//#include <vld.h>
#include <stdarg.h>
#include <stdio.h>

//////////////////////////////////////////////////////////////////////////
//					  !! EMITTER CONTROL BOX !!                         //
//		    Use the following variables to change parameters	        //
																		//
// note: emitter 1 (emitter_)											//
glm::vec3 emitter1_pos = glm::vec3(23.0f, 1.8f, 35.0f);					//
float emitter1_scale = 0.025f;											//
float emitter1_sfactor = 0.1f;											//
float emitter1_lifetime = 3.0f;											//
int emitter1_particle_amount = 100;										//
																	    //
// note: emitter 2 (emitter_2)											//
glm::vec3 emitter2_pos = glm::vec3(25.0f, 1.8f, 35.0f);					//
float emitter2_scale = 0.15f;											//
float emitter2_sfactor = -0.05f;										//
float emitter2_lifetime = 3.0f;											//
int emitter2_particle_amount = 100;										//
//////////////////////////////////////////////////////////////////////////

static void
camera_controller(camera &cam, 
                  const keyboard_device *keyboard, 
                  const mouse_device *mouse,
                  const float deltatime)
{
   static v2 prev_mouse_position = {};

   // note: camera and mouse settings
   const float camera_speed = 5.0f;
   const float mouse_sensitivity = 3.0f;
   const float mouse_yaw_factor = 0.022f;
   const float mouse_pitch_factor = -0.022f;

   // note: camera orientation
   const v2 mouse_position = { (float)mouse->x_, (float)mouse->y_ };
   if (mouse->buttons_[MOUSE_BUTTON_RIGHT].down_)
   {
      const v2 mouse_delta =
      {
         mouse_position.x_ - prev_mouse_position.x_,
         mouse_position.y_ - prev_mouse_position.y_,
      };
      prev_mouse_position = mouse_position;

      if (mouse_delta.x_ != 0.0f)
      {
         cam.rotate_y(deltatime * mouse_delta.x_ * mouse_yaw_factor * mouse_sensitivity);
      }
      if (mouse_delta.y_ != 0.0f)
      {
         cam.rotate_x(deltatime * mouse_delta.y_ * -mouse_pitch_factor * mouse_sensitivity);
      }
   }
   else
   {
      prev_mouse_position = mouse_position;
   }
   
   // note: camera movement
   if (keyboard->keys_[KEYCODE_KEY_W].down_)
   {
      cam.move_forward(deltatime * camera_speed);
   }
   if (keyboard->keys_[KEYCODE_KEY_S].down_)
   {
      cam.move_forward(deltatime * -camera_speed);
   }
   if (keyboard->keys_[KEYCODE_KEY_A].down_)
   {
      cam.move_strafe(deltatime * -camera_speed);
   }
   if (keyboard->keys_[KEYCODE_KEY_D].down_)
   {
      cam.move_strafe(deltatime * camera_speed);
   }

   // note: costructs view matrix and frustum
   cam.update();
}

sandbox_app::sandbox_app()
   : debug_renderer_(render_sys_)
   , skybox_(render_sys_)
   , terrain_(render_sys_)
{
}

sandbox_app::~sandbox_app()
{
}

bool sandbox_app::init()
{
   // note: initialize camera settings
   cam_.set_projection(1280.0f, 720.0f, glm::radians(45.0f), 0.5f, 1000.0f);
   cam_.position_ = { 25.0f, 1.8f, 28.0f };

   if (!skybox_.init())
   {
      HC_ASSERT(false);
   }

   if (!terrain_.init())
   {
      HC_ASSERT(false);
   }

   // note: unit quad/cube geometry
   {
      const float Q = 0.5f;
      vertex vertices[] =
      {
	  // note: plane vertices
	  
	  { {-Q, Q, 0.0f, }, { 0.0f, 0.0f }, { 0.0f, 0.0f, 0.0f, 1.0f }, }, // top left
	  { { Q, Q, 0.0f, }, { 1.0f, 0.0f }, { 0.0f, 0.0f, 0.0f, 1.0f }, }, // top right
	  { { Q,-Q, 0.0f, }, { 1.0f, 1.0f }, { 0.0f, 0.0f, 0.0f, 1.0f }, }, // bottom right
	  
	  { { Q,-Q, 0.0f, }, { 1.0f, 1.0f }, { 0.0f, 0.0f, 0.0f, 1.0f }, }, // bottom right
	  { {-Q,-Q, 0.0f, }, { 0.0f, 1.0f }, { 0.0f, 0.0f, 0.0f, 1.0f }, }, // bottom left
	  { {-Q, Q, 0.0f, }, { 0.0f, 0.0f }, { 0.0f, 0.0f, 0.0f, 1.0f }, }, // top left
      };

	  vertex verticescube[] =
	  {
	  // note: cube vertices
	  // front
				   { { -Q,  Q, -Q, }, { 0.0f, 0.0f } },
				   { {  Q,  Q, -Q, }, { 1.0f, 0.0f } },
				   { {  Q, -Q, -Q, }, { 1.0f, 1.0f } },
				   { {  Q, -Q, -Q, }, { 1.0f, 1.0f } },
				   { { -Q, -Q, -Q, }, { 0.0f, 1.0f } },
				   { { -Q,  Q, -Q, }, { 0.0f, 0.0f } },

				   // right
				   { {  Q,  Q, -Q, }, { 0.0f, 0.0f } },
				   { {  Q,  Q,  Q, }, { 1.0f, 0.0f } },
				   { {  Q, -Q,  Q, }, { 1.0f, 1.0f } },
				   { {  Q, -Q,  Q, }, { 1.0f, 1.0f } },
				   { {  Q, -Q, -Q, }, { 0.0f, 1.0f } },
				   { {  Q,  Q, -Q, }, { 0.0f, 0.0f } },

				   // back
				   { {  Q,  Q,  Q, }, { 0.0f, 0.0f } },
				   { { -Q,  Q,  Q, }, { 1.0f, 0.0f } },
				   { { -Q, -Q,  Q, }, { 1.0f, 1.0f } },
				   { { -Q, -Q,  Q, }, { 1.0f, 1.0f } },
				   { {  Q, -Q,  Q, }, { 0.0f, 1.0f } },
				   { {  Q,  Q,  Q, }, { 0.0f, 0.0f } },

				   // left
				   { { -Q,  Q,  Q, }, { 0.0f, 0.0f } },
				   { { -Q,  Q, -Q, }, { 1.0f, 0.0f } },
				   { { -Q, -Q, -Q, }, { 1.0f, 1.0f } },
				   { { -Q, -Q, -Q, }, { 1.0f, 1.0f } },
				   { { -Q, -Q,  Q, }, { 0.0f, 1.0f } },
				   { { -Q,  Q,  Q, }, { 0.0f, 0.0f } },

				   // top
				   { { -Q,  Q,  Q, }, { 0.0f, 0.0f } },
				   { {  Q,  Q,  Q, }, { 1.0f, 0.0f } },
				   { {  Q,  Q, -Q, }, { 1.0f, 1.0f } },
				   { {  Q,  Q, -Q, }, { 1.0f, 1.0f } },
				   { { -Q,  Q, -Q, }, { 0.0f, 1.0f } },
				   { { -Q,  Q,  Q, }, { 0.0f, 0.0f } },

				   // bottom
					{ { -Q, -Q, -Q, }, { 0.0f, 0.0f } },
				   { {  Q, -Q, -Q, }, { 1.0f, 0.0f } },
				   { {  Q, -Q,  Q, }, { 1.0f, 1.0f } },
				   { {  Q, -Q,  Q, }, { 1.0f, 1.0f } },
				   { { -Q, -Q,  Q, }, { 0.0f, 1.0f } },
				   { { -Q, -Q, -Q, }, { 0.0f, 0.0f } },
	  };

	  // note: reference to vertices array for dynamic vertex buffer update in tick()
	  vert = *vertices;

      unit_quad_model_.count_ = sizeof(vertices) / sizeof(vertices[0]);
      if (!render_sys_.create_vertex_buffer(unit_quad_model_.buffer_,
                                            RENDER_SYSTEM_BUFFER_ACCESS_DYNAMIC,
                                            sizeof(vertices),
                                            vertices))
      {
         HC_ASSERT(false);
      }

	  unit_cube_model_.count_ = sizeof(verticescube) / sizeof(verticescube[0]);
	  if (!render_sys_.create_vertex_buffer(unit_cube_model_.buffer_,
											RENDER_SYSTEM_BUFFER_ACCESS_STATIC,
										    sizeof(verticescube),
											verticescube))
	  {
		  HC_ASSERT(false);
	  }
   }
   
   {
	  // note: load emitter vertex shader
	  file_content emitter_vertex_shader_file_content = {};
	  if (!read_file_from_disk("assets/emitter/emitter_vertex_shader.txt", &emitter_vertex_shader_file_content)) { HC_ASSERT(false); }

	  // note: load emitter fragment shader
	  file_content emitter_fragment_shader_file_content = {};
	  if (!read_file_from_disk("assets/emitter/emitter_fragment_shader.txt", &emitter_fragment_shader_file_content)) { HC_ASSERT(false); }

	  // note: create shader program
	  if (!render_sys_.create_shader(emitter_program_,
		  (const char *)emitter_vertex_shader_file_content.data_,
		  (const char *)emitter_fragment_shader_file_content.data_))
	  {
		  HC_ASSERT(false);
	  }

	  // note: load particle vertex shader
	  file_content particle_vertex_shader_file_content = {};
	  if (!read_file_from_disk("assets/particle/particle_vertex_shader.txt", &particle_vertex_shader_file_content)) { HC_ASSERT(false); }

	  // note: load particle fragment shader
	  file_content particle_fragment_shader_file_content = {};
	  if (!read_file_from_disk("assets/particle/particle_fragment_shader.txt", &particle_fragment_shader_file_content)) { HC_ASSERT(false); }

	  // note: create shader program
	  if (!render_sys_.create_shader(particle_program_,
		  (const char *)particle_vertex_shader_file_content.data_,
		  (const char *)particle_fragment_shader_file_content.data_))
	  {
		  HC_ASSERT(false);
	  }

      // note: release shader sources
	  release_file_content(&emitter_vertex_shader_file_content);
	  release_file_content(&emitter_fragment_shader_file_content);
	  release_file_content(&particle_vertex_shader_file_content);
	  release_file_content(&particle_fragment_shader_file_content);
   }

   // note: create sampler state
   {
      if (!render_sys_.create_sampler_state(linear_sampler_,
                                            RENDER_SYSTEM_SAMPLER_FILTER_LINEAR,
                                            RENDER_SYSTEM_SAMPLER_ADDRESS_MODE_CLAMP,
                                            RENDER_SYSTEM_SAMPLER_ADDRESS_MODE_CLAMP))
      {
         HC_ASSERT(false);
      }
   }

   // note: build vertex format
   vertex_format_.add_attribute(vertex_format::ATTRIBUTE_SEMANTIC_POSITION,
                                vertex_format::ATTRIBUTE_FORMAT_FLOAT,
                                3,
                                false);
   vertex_format_.add_attribute(vertex_format::ATTRIBUTE_SEMANTIC_TEXCOORD,
                                vertex_format::ATTRIBUTE_FORMAT_FLOAT,
                                2,
                                false);
   vertex_format_.add_attribute(vertex_format::ATTRIBUTE_SEMANTIC_COLOR,
								vertex_format::ATTRIBUTE_FORMAT_FLOAT,
								4,
								false);


   if (!debug_renderer_.init(1280, 720))
      return false;

   // note: color and depth attachments
   texture_index_ = 0;

   // note: set back buffer dimensions
   default_framebuffer_ = {};
   default_framebuffer_.width_ = 1280;
   default_framebuffer_.height_ = 720;

   // note: create the render-to-texture framebuffer
   const render_system_framebuffer_format color_formats[] = 
   { 
      RENDER_SYSTEM_FRAMEBUFFER_FORMAT_RGBA8, 
      RENDER_SYSTEM_FRAMEBUFFER_FORMAT_D32 
   };

   framebuffer_ = {};
   if (!render_sys_.create_framebuffer(framebuffer_,
                                       128,
                                       72,
                                       2,
                                       color_formats,
                                       RENDER_SYSTEM_FRAMEBUFFER_FORMAT_NONE))
   {
      HC_ASSERT(false);
   }

   // note: create emitters and generate particles ** particle amount (int), speed, gravity, life
   emitter_ = std::make_shared<emitter>(emitter1_particle_amount, emitter1_lifetime, std::make_shared<camera>(cam_), emitter1_pos, emitter1_scale, emitter1_sfactor);
   emitter_->generateparticles();
   emitter_2 = std::make_shared<emitter>(emitter2_particle_amount, emitter2_lifetime, std::make_shared<camera>(cam_), emitter2_pos, emitter2_scale, emitter2_sfactor);
   emitter_2->generateparticles();

   return true;
}

bool sandbox_app::tick(double app_time, double frame_time,
                       const keyboard_device *keyboard,
                       const mouse_device *mouse)
{

   const float deltatime = (float)frame_time;
   timer += (float)deltatime;
   deltatimer = deltatime;

   camera_controller(cam_, keyboard, mouse, deltatime);

   // note: color and depth attachment switch
   if (keyboard->keys_[KEYCODE_SPACE].pressed_)
   {
	  timer = (float)app_time;
      texture_index_ = (++texture_index_ & 1);
   }

   // note: debug text
   {
   debug_renderer_.pre_frame();
   debug_renderer_.draw_text_format({ 2.0f, 2.0f }, 
                                    "%dx%d", 
                                    mouse->x_, 
                                    mouse->y_);
   debug_renderer_.draw_text_format({ 2.0f, 12.0f }, 
                                    "x: %f y: %f z: %f", 
                                    cam_.position_.x, 
                                    cam_.position_.y, 
                                    cam_.position_.z);
   debug_renderer_.draw_text_format({ 2.0f, 20.0f },
                                    "pitch: %f",
                                    cam_.pitch_);
   debug_renderer_.draw_text_format({ 2.0f, 28.0f },
                                    "yaw:   %f",
                                    cam_.yaw_);
   debug_renderer_.draw_text_format({ 2.0f, 36.0f },
                                    "roll:  %f",
                                    cam_.roll_);

   debug_renderer_.draw_text_format({ 2.0f, 44.0f },
                                    "tricount: %d rtt: %s",
                                    frame_vertex_count_,
                                    texture_index_ ? "depth" : "color");
   
   // note: keep track of particle amount
   debug_renderer_.draw_text_format({ 2.0f, 60.0f },
	   "tommistimer_: %f",
	   (float)emitter_->particles[0]->tommistimer_);

   // note: particle debugging
   if (!emitter_->particles.empty())
   {
	   debug_renderer_.draw_text_format({ 2.0f, 500.0f },
		   "Total amount of particles: %f",
		   (float)emitter_->particles.size() + (float)emitter_2->particles.size());
   }
   }  

   // note: update and emit particles
   emitter_->update(deltatimer);
   emitter_2->update(deltatimer);

   // note: dynamically update vertex buffer
   render_sys_.update_vertex_buffer(unit_quad_model_.buffer_, sizeof(&vert), &vert);

   return !keyboard->keys_[KEYCODE_ESCAPE].pressed_;
}

void sandbox_app::render()
{
   frame_vertex_count_ = 0;

   // begin: render-to-texture (framebuffer)
   render_sys_.set_framebuffer(framebuffer_);
   render_sys_.clear({ 1.0f, 0.0f, 0.0f, 1.0f });

   terrain_.render(cam_);

   // note: "normal rendering"
   render_sys_.set_framebuffer(default_framebuffer_);
   render_sys_.clear({ 0.1f, 0.2f, 0.3f, 1.0f });
   render_sys_.set_viewport(0, 0, 1280, 720);

   // note: render skybox
   skybox_.render(cam_);
   frame_vertex_count_ += 12; // note: hardcode!

   // note: render terrain
   terrain_.render(cam_);
   frame_vertex_count_ += terrain_.primitive_count_ / 3; // note: hardcode!

   // note: pipeline settings
   render_sys_.set_blend_state(true);
   render_sys_.set_depth_state(true, true);
   render_sys_.set_rasterizer_state(RENDER_SYSTEM_CULL_MODE_BACK);

   // note: emitter frustum culling
   if (cam_.is_inside(emitter_->emitter_position_))
   {
	   glm::mat4 model_ = glm::mat4(1);

	   // note: input assembly
	   render_sys_.set_vertex_buffer(unit_cube_model_.buffer_);
	   render_sys_.set_vertex_format(vertex_format_);

	   // note: emitter settings 
	   {
		   model_ = glm::translate(model_, emitter_->emitter_position_);
		   model_ = glm::scale(model_, glm::vec3(0.25));
		   render_sys_.set_shader_program(emitter_program_);
	   }

	   // note: emitter shader uniforms
	   {
		   render_sys_.set_shader_uniform(emitter_program_,
			   RENDER_SYSTEM_UNIFORM_TYPE_MATRIX,
			   "u_projection",
			   1,
			   glm::value_ptr(cam_.projection_));

		   render_sys_.set_shader_uniform(emitter_program_,
			   RENDER_SYSTEM_UNIFORM_TYPE_MATRIX,
			   "u_view",
			   1,
			   glm::value_ptr(cam_.view_));
		   render_sys_.set_shader_uniform(emitter_program_,
			   RENDER_SYSTEM_UNIFORM_TYPE_MATRIX,
			   "u_world",
			   1,
			   glm::value_ptr(model_));
	   }

	   // note: emitter draw call
	   render_sys_.draw(RENDER_SYSTEM_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST,
		   0,
		   unit_cube_model_.count_);
   }

   // note: particles frustum culling
   if (cam_.is_inside(emitter_->emitter_position_))
   {
	   // note: send to shader uniform
	   render_sys_.set_shader_uniform(particle_program_,
		   RENDER_SYSTEM_UNIFORM_TYPE_FLOAT,
		   "u_timer",
		   1,
		   &timer);

	   // weird but renders:
	   glm::mat4 particle_model_ = glm::mat4(1);

		 // note: set shader program
	   render_sys_.set_shader_program(particle_program_);

		// note: send to shader uniform
	   render_sys_.set_shader_uniform(particle_program_,
		   RENDER_SYSTEM_UNIFORM_TYPE_MATRIX,
		   "u_projection",
		   1,
		   glm::value_ptr(cam_.projection_));		   
	   
	   // note: input assembly
	   render_sys_.set_vertex_buffer(unit_quad_model_.buffer_);
	   render_sys_.set_vertex_format(vertex_format_);
	   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	   // note: don't render to the depth buffer ** also removes the mirror effect from the model_cube with (false, true)
	   render_sys_.set_depth_state(false, false);

	   for (int i = 0; i < emitter_->particles.size(); i++)
	   {
		   // note: ModelViewMatrix update/settings & billboarding
		   glm::mat4 modelmatrix_ = glm::mat4(1);

		   // note: weird but renders
		   particle_model_ = glm::translate(glm::mat4(1.0f), emitter_->particles[i]->position_);

		   // note: model matrix
		   modelmatrix_ = glm::translate(modelmatrix_, emitter_->particles[i]->position_);
		   modelmatrix_ = glm::rotate(particle_model_, emitter_->particles[i]->rotation_, glm::vec3(0.0f, 0.0f, 1.0f));
		   modelmatrix_ = glm::scale(particle_model_, glm::vec3(emitter_->particles[i]->scale_));

		   // note: modelview matrix
		   glm::mat4 modelViewMatrix_ = cam_.view_ * modelmatrix_;

		   // note: spherical billboarding i.e. exclude column 1 to make it cylindrical ** how to: identity matrix, but replace 1's (scaling part of the matrix) with the particles' scale 
		   // note: column 0:
		   modelViewMatrix_[0][0] = emitter_->particles[i]->scale_;
		   modelViewMatrix_[0][1] = 0;
		   modelViewMatrix_[0][2] = 0;
		   // note: column 1:
		   modelViewMatrix_[1][0] = 0;
		   modelViewMatrix_[1][1] = emitter_->particles[i]->scale_;
		   modelViewMatrix_[1][2] = 0;
		   // note: column 2
		   modelViewMatrix_[2][0] = 0;
		   modelViewMatrix_[2][1] = 0;
		   modelViewMatrix_[2][2] = emitter_->particles[i]->scale_;

		   //// note: send to shader uniform
		   render_sys_.set_shader_uniform(particle_program_,
			   RENDER_SYSTEM_UNIFORM_TYPE_MATRIX,
			   "u_modelview",
			   1,
			   glm::value_ptr(modelViewMatrix_));

		   // note: particle draw call
		   render_sys_.draw(RENDER_SYSTEM_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST,
			   0,
			   unit_quad_model_.count_);
	   }

	   // reset blend and depth state
	   render_sys_.set_depth_state(true, true);
	   glDisable(GL_BLEND);
   }

   // note: emitter2 frustum culling
   if (cam_.is_inside(emitter_2->emitter_position_))
   {
	   glm::mat4 model_ = glm::mat4(1);

	   // note: input assembly
	   render_sys_.set_vertex_buffer(unit_cube_model_.buffer_);
	   render_sys_.set_vertex_format(vertex_format_);

	   // note: emitter settings 
	   {
		   model_ = glm::translate(model_, emitter_2->emitter_position_);
		   model_ = glm::scale(model_, glm::vec3(0.25));
		   render_sys_.set_shader_program(emitter_program_);
	   }

	   // note: emitter shader uniforms
	   {
		   render_sys_.set_shader_uniform(emitter_program_,
			   RENDER_SYSTEM_UNIFORM_TYPE_MATRIX,
			   "u_projection",
			   1,
			   glm::value_ptr(cam_.projection_));

		   render_sys_.set_shader_uniform(emitter_program_,
			   RENDER_SYSTEM_UNIFORM_TYPE_MATRIX,
			   "u_view",
			   1,
			   glm::value_ptr(cam_.view_));
		   render_sys_.set_shader_uniform(emitter_program_,
			   RENDER_SYSTEM_UNIFORM_TYPE_MATRIX,
			   "u_world",
			   1,
			   glm::value_ptr(model_));
	   }

	   // note: emitter draw call
	   render_sys_.draw(RENDER_SYSTEM_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST,
		   0,
		   unit_cube_model_.count_);
   }

   // note: particles frustum culling
   if (cam_.is_inside(emitter_2->emitter_position_))
   {
	   	   // note: send to shader uniform
	   render_sys_.set_shader_uniform(particle_program_,
		   RENDER_SYSTEM_UNIFORM_TYPE_FLOAT,
		   "u_timer",
		   1,
		   &timer);

	   // weird but renders:
	   glm::mat4 particle_model_ = glm::mat4(1);

		 // note: set shader program
	   render_sys_.set_shader_program(particle_program_);

		// note: send to shader uniform
	   render_sys_.set_shader_uniform(particle_program_,
		   RENDER_SYSTEM_UNIFORM_TYPE_MATRIX,
		   "u_projection",
		   1,
		   glm::value_ptr(cam_.projection_));		   
	   
	   // note: input assembly
	   render_sys_.set_vertex_buffer(unit_quad_model_.buffer_);
	   render_sys_.set_vertex_format(vertex_format_);
	   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	   // note: don't render to the depth buffer ** also removes the mirror effect from the model_cube with (false, true)
	   render_sys_.set_depth_state(false, false);

	   for (int i = 0; i < emitter_2->particles.size(); i++)
	   {
		   // note: ModelViewMatrix update/settings & billboarding
		   glm::mat4 modelmatrix_ = glm::mat4(1);

		   // note: weird but renders
		   particle_model_ = glm::translate(glm::mat4(1.0f), emitter_2->particles[i]->position_);

		   // note: model matrix
		   modelmatrix_ = glm::translate(modelmatrix_, emitter_2->particles[i]->position_);
		   modelmatrix_ = glm::rotate(particle_model_, emitter_2->particles[i]->rotation_, glm::vec3(0.0f, 0.0f, 1.0f));
		   modelmatrix_ = glm::scale(particle_model_, glm::vec3(emitter_2->particles[i]->scale_));

		   // note: modelview matrix
		   glm::mat4 modelViewMatrix_ = cam_.view_ * modelmatrix_;

		   // note: spherical billboarding i.e. exclude column 1 to make it cylindrical ** how to: identity matrix, but replace 1's (scaling part of the matrix) with the particles' scale 
		   // note: column 0:
		   modelViewMatrix_[0][0] = emitter_2->particles[i]->scale_;
		   modelViewMatrix_[0][1] = 0;
		   modelViewMatrix_[0][2] = 0;
		   // note: column 1:
		   modelViewMatrix_[1][0] = 0;
		   modelViewMatrix_[1][1] = emitter_2->particles[i]->scale_;
		   modelViewMatrix_[1][2] = 0;
		   // note: column 2
		   modelViewMatrix_[2][0] = 0;
		   modelViewMatrix_[2][1] = 0;
		   modelViewMatrix_[2][2] = emitter_2->particles[i]->scale_;

		   //// note: send to shader uniform
		   render_sys_.set_shader_uniform(particle_program_,
			   RENDER_SYSTEM_UNIFORM_TYPE_MATRIX,
			   "u_modelview",
			   1,
			   glm::value_ptr(modelViewMatrix_));

		   // note: particle draw call
		   render_sys_.draw(RENDER_SYSTEM_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST,
			   0,
			   unit_quad_model_.count_);
	   }

	   // reset blend and depth state
	   render_sys_.set_depth_state(true, true);
	   glDisable(GL_BLEND);
   }

   // note: render all debug text
   debug_renderer_.render();
   frame_vertex_count_ += debug_renderer_.vertex_cache_count_ / 3; // note: hardcode!
}

void sandbox_app::exit()
{
	// note: clean emitter & particle stuff
	emitter_->particles.clear();
	emitter_2->particles.clear();
	render_sys_.destroy_shader(emitter_program_);
	render_sys_.destroy_shader(particle_program_);

  // render_sys_.destroy_texture(unit_cube_texture_);
   render_sys_.destroy_sampler_state(linear_sampler_);
   render_sys_.destroy_vertex_buffer(unit_quad_model_.buffer_);
   render_sys_.destroy_vertex_buffer(unit_cube_model_.buffer_);

   terrain_.exit();
   skybox_.exit();
   debug_renderer_.exit();
}

// note: we need to implement this function to enable library winmain 
//       to create an instance of our application
application *create_application(int /*argc*/, char ** /*argv*/)
{
   return new sandbox_app;
}
