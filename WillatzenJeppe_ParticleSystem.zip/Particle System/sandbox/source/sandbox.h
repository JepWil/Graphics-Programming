// sandbox.h

#include <halcyon.h>
#include <vector>
#include "iterator.h"
#include "debug_renderer.h"
#include "camera.h"
#include "skybox.h"
#include "terrain_renderer.h"
#include <memory>
#include <iterator>
#include <glm/gtx/norm.hpp> // for vector norms: used to calculate squared length in line 67
//in place of dot product of the distance vector returned by distance() for efficiency
#define GLM_ENABLE_EXPERIMENTAL

GLfloat timer; // note: general timer
GLfloat deltatimer;

// swap() is courtesy of Adam Olsson (97!) used with permission
template <class T>
void swap(T *xp, T *yp) {
	T temp = *xp;
	*xp = *yp;
	*yp = temp;
}

struct vertex
{
   v3 position_;
   v2 texcoord_;
   v4 color_;
};

struct color
{
	GLfloat rgb[3];
	
	void colorize()
	{
		rgb[0] = (float)random(0, 266);
		rgb[1] = (float)random(0, 266);
		rgb[2] = (float)random(0, 266);
	}

	double random(double p_iMin, double p_iMax)
	{
		double v = (double)rand() / RAND_MAX;
		return p_iMin + v * (p_iMax - p_iMin);
	}
};

struct model
{
   int count_;
   vertex_buffer buffer_;
   float radius_;
   glm::vec3 position_;
   glm::mat4 transform_;
};

struct particle
{
	glm::vec3 position_;
	glm::vec3 velocity_;
	glm::vec3 acceleration_;
	glm::vec4 color_;
	GLfloat lifetime_;
	GLfloat rotation_;
	GLfloat scale_;
	GLfloat elapsedtime_ = 0.0f;
	float time_spawn_ = 0.0f;
	float tommistimer_ = 0.0f;
	double emittimer_ = 0.00;
	bool moving;
	float distance = 0.0f;
	float scalingfactor_ = 0.0f;

	particle(glm::vec3 arg_pos, glm::vec3 arg_velo, GLfloat arg_life, GLfloat arg_rotation, GLfloat arg_scale, const float arg_time_spawn, double arg_emittimer, float arg_scale_factor)
	{
		 position_ = arg_pos;
		 velocity_ = arg_velo;
		 lifetime_ = arg_life;
		 rotation_ = arg_rotation;
		 scale_ = arg_scale;
		 time_spawn_ = arg_time_spawn;
		 emittimer_ = arg_emittimer;
		 scalingfactor_ = arg_scale_factor;
	}

	// update
	bool update(float arg_deltatime, std::shared_ptr<camera> arg_cam)
	{
		// note: calculate distance to camera
		distance = glm::length2(glm::distance(position_, arg_cam->position_));
		
		// note: move particle
		emittimer_ -= arg_deltatime;
		if (emittimer_ <= 0)
		{
			velocity_.y += arg_deltatime;
			acceleration_ = velocity_ * arg_deltatime;
			position_ += acceleration_;
			moving = true;
		}

		// !! Behold !! Increase scale & subtract time 
		if (moving)
		{
			if (scale_ > 0)
			{
				scale_ += arg_deltatime * scalingfactor_;
			}
			if (scale_ < 0)
			{
				scale_ -= arg_deltatime * scalingfactor_;
			}	
			tommistimer_ -= arg_deltatime;
		}

		return tommistimer_ > 0.0f;
	}
};

// sorthightolow() and sortuphighlow() insertion sort is courtesy of Karl, a.k.a. ThinMatrix https://www.dropbox.com/sh/be1lrxk0h9dhdx7/AAD8G5xdEBdEeTJOi4LnGXePa?dl=0 used with permission (fair use / till�ten anv�nding)
struct insertionsort
{
	void sorthightolow(std::vector<std::shared_ptr<particle>> arg_particle_vector)
	{
		for (int i = 1; i < arg_particle_vector.size(); i++)
		{
			std::shared_ptr<particle> item = arg_particle_vector[i];
			if (item->distance > arg_particle_vector[i - 1]->distance) // note: compare distance to camera between elements
			{
				sortuphighlow(arg_particle_vector, i);
			}
		}
	}

	void sortuphighlow(std::vector<std::shared_ptr<particle>> arg_particle_vector, int i)
	{
		std::shared_ptr<particle> item = arg_particle_vector[i];
		int attemptPos = i - 1;
		while (attemptPos != 0 && arg_particle_vector[attemptPos - 1]->distance < item->distance)
		{
			attemptPos--;
		}
		arg_particle_vector.erase(arg_particle_vector.begin() + i);
		arg_particle_vector[attemptPos] = item;
	}
};

struct emitter
{
	std::vector<std::shared_ptr<particle>> particles;
	std::shared_ptr<particle> next_particle_;
	std::vector<std::shared_ptr<particle>>::iterator it;
	glm::vec3 emitter_position_;
	std::shared_ptr<camera> cam_;
	insertionsort particles_sorter;

	// note: particle attributes
	int total_particles_;
	GLfloat lifetime_;
	float scale_;
	float scaling_factor_;

	void update(float arg_deltatime)
	{
		if (!particles.empty())
		{
			particles_sorter.sorthightolow(particles); // note: quicker than bubble. Insertion sort because the vector is not completely random.
			//bubblesort();
			for (it = particles.begin(); it != particles.end(); ++it)
			{
				next_particle_ = *it;
				bool alive = next_particle_->update(arg_deltatime, cam_);
				if (!alive)
				{
					resetparticle(next_particle_);
				}
			}
		}
	}
	
	emitter(int arg_total_particles, float arg_lifetime, std::shared_ptr<camera> arg_cam, glm::vec3 arg_pos, float arg_scale, float arg_scaling_factor)
	{
		total_particles_ = arg_total_particles;
		lifetime_ = arg_lifetime;
		cam_ = arg_cam;
		emitter_position_ = arg_pos;
		scale_ = arg_scale;
		scaling_factor_ = arg_scaling_factor;
	}

	void addparticles(std::shared_ptr<particle> particle_)
	{
		particles.push_back(particle_);
	}

	void generateparticles()
	{
		for (int i = 0; i < total_particles_; i++)
		{
			// calculate direction
			double dirx = random(0, 2) - 1;
			double dirz = random(0, 2) - 1;
			glm::vec3 direction = glm::vec3(dirx, 1, dirz);
			direction = glm::normalize(direction);

			// add particle to vector
			auto particle_i = std::make_shared<particle>(emitter_position_, direction, lifetime_, 0.0f, scale_, deltatimer, random(0, 3), scaling_factor_);
			addparticles(particle_i);
		}
	}

	// bubblesort() is courtesy of Adam Olsson (97!) used with permission ** Uncomment the update function to use!
	void bubblesort()
	{
		{
			int i, j;
			for (i = 0; i < particles.size() - 1; i++) {
				// Last i elements are already in place 
				for (j = 0; j < particles.size() - i - 1; j++) {
					if (particles.size() > 0) {
						if (particles[j]->distance < particles[j + 1]->distance) {
							swap(&particles[j], &particles[j + 1]);
						}
					}
				}
			}
		}
	}

	void resetparticle(std::shared_ptr<particle> arg_particle)
	{
		// note: reset positions and timers
		arg_particle->position_ = emitter_position_;
		arg_particle->elapsedtime_ = 0;
		arg_particle->time_spawn_ = timer;
		arg_particle->tommistimer_ = arg_particle->lifetime_;
		arg_particle->emittimer_ = (float)random(0, 3);
		arg_particle->scale_ = scale_;
		arg_particle->moving = false;

		// note: random velocity 
		arg_particle->acceleration_ = glm::vec3(0, 0, 0);
		arg_particle->velocity_.y = 1;
		arg_particle->velocity_.x = (float)random(0, 2) - 1;
		arg_particle->velocity_.z = (float)random(0, 2) - 1;
		arg_particle->velocity_ = glm::normalize(arg_particle->velocity_);
	}

	double random(double p_iMin, double p_iMax)
	{
		double v = (double)rand() / RAND_MAX;
		return p_iMin + v * (p_iMax - p_iMin);
	}
};

struct sandbox_app : application
{
   sandbox_app();
   ~sandbox_app();

   virtual bool init() final;
   virtual bool tick(double app_time, double frame_time,
                     const keyboard_device *keyboard,
                     const mouse_device *mouse) final;
   virtual void render() final;
   virtual void exit() final;

   render_system render_sys_;
   debug_renderer debug_renderer_;

   camera cam_;
   skybox skybox_;
   terrain_renderer terrain_;
   model unit_quad_model_;
   model unit_cube_model_;

   std::shared_ptr<emitter> emitter_;
   std::shared_ptr<emitter> emitter_2;

   shader_program emitter_program_;
   shader_program particle_program_;

   sampler_state linear_sampler_;
   vertex_format vertex_format_;
   vertex vert;

   int texture_index_;
   int frame_vertex_count_;

   framebuffer default_framebuffer_;
   framebuffer framebuffer_;
   
};
