// terrain_renderer.cc

#include "terrain_renderer.h"

#include "render_system_utility.h"
#include "image.h"

// texture source:
// - https://opengameart.org/content/512-by-512-terrain-elevation-map-with-layers

terrain_renderer::terrain_renderer(render_system &render_sys)
   : render_sys_(&render_sys)
{
   program_ = {};
   texture_ = {};
   sampler_ = {};
   vertex_buffer_ = {};
   vertex_format_ = {};
}

terrain_renderer::~terrain_renderer()
{
}

bool terrain_renderer::init()
{
   if (!load_shader_program(render_sys_,
                            program_,
                            "assets/terrain/vertex_shader.txt",
                            "assets/terrain/fragment_shader.txt"))
   {
      HC_ASSERT(false);
   }

   if (!load_texture(render_sys_,
                     texture_,
                     RENDER_SYSTEM_TEXTURE_FORMAT_RGBA8,
                     "assets/terrain/texture.png"))
   {
      HC_ASSERT(false);
   }

   if (!render_sys_->create_sampler_state(sampler_,
                                          RENDER_SYSTEM_SAMPLER_FILTER_LINEAR,
                                          RENDER_SYSTEM_SAMPLER_ADDRESS_MODE_CLAMP,
                                          RENDER_SYSTEM_SAMPLER_ADDRESS_MODE_CLAMP))
   {
      HC_ASSERT(false);
   }

   image heightmap;
   if (!heightmap.load_from_file("assets/terrain/heightmap.png"))
   {
      HC_ASSERT(false);
   }

   const int width = heightmap.width_;
   const int height = heightmap.height_;

   const uint32_t index_count = (width - 1) * (height - 1) * 6;
   const uint32_t index_buffer_size = index_count * sizeof(uint32_t);
   uint32_t *indices = new uint32_t[index_count];

   uint32_t index_index = 0;
   const int index_x_count = width - 1;
   const int index_z_count = height - 1;
   for (int z_coord = 0; z_coord < index_z_count; z_coord++)
   {
      for (int x_coord = 0; x_coord < index_x_count; x_coord++)
      {
         indices[index_index++] = ((z_coord) * width) + (x_coord);
         indices[index_index++] = ((z_coord) * width) + (x_coord + 1);
         indices[index_index++] = ((z_coord + 1) * width) + (x_coord + 1);

         indices[index_index++] = ((z_coord + 1) * width) + (x_coord + 1);
         indices[index_index++] = ((z_coord + 1) * width) + (x_coord);
         indices[index_index++] = ((z_coord)* width) + (x_coord);
      }
   }

   if (!render_sys_->create_index_buffer(index_buffer_,
                                         index_buffer_size,
                                         indices))
   {
      HC_ASSERT(false);
   }

   delete [] indices;

   primitive_count_ = index_count;

   const float horizontal_scale = 0.1f;
   const float vertical_scale = 0.01f;

   const int vertex_count = width * height;
   const int vertex_buffer_size = vertex_count * sizeof(vertex);
   vertex *vertices = new vertex[vertex_count];
   for (int index = 0; index < vertex_count; index++)
   {
      int x_coord = index % width;
      int z_coord = index / width;

      float x = (float)(x_coord) * horizontal_scale;
      float y = (float)(heightmap.data_[index * 4] & 0xff) * vertical_scale;
      float z = (float)(z_coord) * horizontal_scale;

      float u = (float)x_coord / (float)width;
      float v = (float)z_coord / (float)height;

      vertices[index].position_ = { x, y, z };
      vertices[index].texcoord_ = { u, v };
      vertices[index].normal_ = { 0.0f, 1.0f, 0.0f };
   }
   
   if (!render_sys_->create_vertex_buffer(vertex_buffer_,
                                          RENDER_SYSTEM_BUFFER_ACCESS_STATIC,
                                          vertex_buffer_size,
                                          vertices))
   {
      HC_ASSERT(false);
   }

   delete [] vertices;
   heightmap.release();

   // note: define terrain vertex format
   vertex_format_.add_attribute(vertex_format::ATTRIBUTE_SEMANTIC_POSITION,
                                vertex_format::ATTRIBUTE_FORMAT_FLOAT,
                                3,
                                false);
   vertex_format_.add_attribute(vertex_format::ATTRIBUTE_SEMANTIC_TEXCOORD,
                                vertex_format::ATTRIBUTE_FORMAT_FLOAT,
                                2,
                                false);
   vertex_format_.add_attribute(vertex_format::ATTRIBUTE_SEMANTIC_NORMAL,
                                vertex_format::ATTRIBUTE_FORMAT_FLOAT,
                                3,
                                true);

   return true;
}

void terrain_renderer::exit()
{
   render_sys_->destroy_shader(program_);
   render_sys_->destroy_texture(texture_);
   render_sys_->destroy_sampler_state(sampler_);
   render_sys_->destroy_vertex_buffer(vertex_buffer_);
   render_sys_->destroy_index_buffer(index_buffer_);
}

void terrain_renderer::render(camera &cam)
{
   // note: pipeline settings
   render_sys_->set_shader_program(program_);
   render_sys_->set_blend_state(false);
   render_sys_->set_depth_state(true, true);
   render_sys_->set_rasterizer_state(RENDER_SYSTEM_CULL_MODE_FRONT);

   // note: shader uniforms
   render_sys_->set_shader_uniform(program_,
                                   RENDER_SYSTEM_UNIFORM_TYPE_MATRIX,
                                   "u_projection",
                                   1,
                                   glm::value_ptr(cam.projection_));
   render_sys_->set_shader_uniform(program_,
                                   RENDER_SYSTEM_UNIFORM_TYPE_MATRIX,
                                   "u_view",
                                   1,
                                   glm::value_ptr(cam.view_));

   // note: input assembly
   render_sys_->set_index_buffer(index_buffer_);
   render_sys_->set_vertex_buffer(vertex_buffer_);
   render_sys_->set_vertex_format(vertex_format_);

   // note: resource bindings
   render_sys_->set_texture(texture_, 0);
   render_sys_->set_sampler_state(sampler_, 0);

   // note: draw call
   render_sys_->draw_indexed(RENDER_SYSTEM_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST,
                             RENDER_SYSTEM_INDEX_TYPE_UNSIGNED_INT,
                             0,
                             primitive_count_);
}
