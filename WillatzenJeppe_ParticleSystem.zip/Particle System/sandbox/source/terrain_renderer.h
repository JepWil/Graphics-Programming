// terrain_renderer.h

#ifndef TERRAIN_RENDERER_H_INCLUDED
#define TERRAIN_RENDERER_H_INCLUDED

#include <halcyon.h>
#include "camera.h"

struct terrain_renderer
{
   terrain_renderer(render_system &render_sys);
   ~terrain_renderer();

   bool init();
   void exit();

   void render(camera &cam);

   render_system *render_sys_;
   
   shader_program program_;
   texture texture_;
   sampler_state sampler_;
   index_buffer index_buffer_;
   vertex_buffer vertex_buffer_;
   vertex_format vertex_format_;
   int primitive_count_;

   struct vertex
   {
      v3 position_;
      v2 texcoord_;
      v3 normal_;
   };
};

#endif // TERRAIN_RENDERER_H_INCLUDED
