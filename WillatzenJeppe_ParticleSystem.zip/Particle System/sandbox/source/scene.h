// scene.h

#ifndef SCENE_H_INCLUDED
#define SCENE_H_INCLUDED

#include <halcyon.h>
#include <vector>

struct bounding_sphere
{
   glm::vec3 center_;
   float radius_;
};

struct scene
{
   struct node
   {
      node();

      int id_;
      bounding_sphere sphere_;
      glm::mat4 transform_;
   };

   scene();
   ~scene();

   int node_id_generator_;
   int node_count_;
   std::vector<node> nodes_;
};

#endif // SCENE_H_INCLUDED
